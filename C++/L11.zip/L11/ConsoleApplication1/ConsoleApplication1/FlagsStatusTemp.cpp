#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <bitset>
#include "windows.h"
using namespace std;






int main()
{
	printf("Lab_No_011 Processor Flags And Condition Codes\n");
	printf("Module: C++ progrmming \n");
	printf("Ashahi Shafin, ID#23607352\n");
	printf("CET3510-OL25\n");
	printf("Presentation date: May 5, 2021\n");
	printf("Due date: May 12, 2021\n");
	printf("Example 11.2 FlagsStatusTemp.cpp\n");
	printf("file name: 11.2 FlagsStatusTemp.cpp\n");
	printf("-----------------------------------------------------------------------------\n");

	short flagValue;
	unsigned int ui1, ui2; 
	int i = 0; 
	char ch, ch1, ch2; 
	ch1 = 'Y'; 


	while (ch1 == 'Y' || ch1 == 'y') 
	{
		cout << "Input two 8-bit unsigned number operands to compare.\n";
		cin >> ui1; 
		cin >> ui2; 
		_asm 
		{
			mov EAX, ui1; 
			mov EBX, ui2; 
			cmp EAX, EBX; 
			PUSHF;
			POP DX; 
			mov flagValue, DX;
		}
		bitset<16> flagBits(flagValue);//This is a bitset to display 16 bits
		cout << "Examine the carry bit (position 0) and zero bit (position 6)" << endl; 
		cout << "Compare with conditional jumps of JC (JNC) and JZ(JNZ)" << endl; 
		cout << "The bits of of FLAGS register are " << flagBits << endl; 
		cout << "------------------------------" << endl;
		_asm
		{
			mov EAX, ui1; 
			mov EBX, ui2; 
			cmp EAX, EBX; 
			JC LC; 
			JNC LNC; 
		}
		if (i == -1)
		{
		LC: //label LC
			cout << "The carry bit is set (C=1)" << endl; 
			cout << "The first operand " << ui1 << " < the second operand " << ui2 << endl; 
		}
		else if (i == -2)
		{
		LNC:
			cout << "The carry is clear (C=0)" << endl; 
			cout << "The first operand " << ui1 << " >= the second operand " << ui2 << endl; 
		}
		else
		{
		}
		_asm
		{
			mov EAX, ui1;  
			mov EBX, ui2;  
			cmp EAX, EBX;  
			JE LZ; 
			JNE LNZ;
		}
		if (i == 1)
		{
		LZ: //Label LZ
			cout << "The zero bit is set (Z=1)" << endl; 
			cout << "The first operand " << ui1 << " = the second operand " << ui2 << endl; 
		}
		else if (i == 2)
		{
		LNZ: //Label LNZ
			cout << "The zero is clear (Z=0) " << endl; 
			cout << "The first operand " << ui1 << " != the second operand " << ui2 << endl; 
		}
		else
		{

		}
		cout << "Would you like to continue the comparison> (Y/N) Enter Y(y) or N(n) " << endl;
		cin >> ch; 
		ch1 = ch;  
	}
	system("pause");
	exit(0);
	return 0;
}
